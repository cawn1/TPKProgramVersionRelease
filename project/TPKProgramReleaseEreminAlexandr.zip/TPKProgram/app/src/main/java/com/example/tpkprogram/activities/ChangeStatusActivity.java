package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.Order;
import com.example.tpkprogram.managers.OrderManager;
import com.example.tpkprogram.R;

import java.util.List;

public class ChangeStatusActivity extends AppCompatActivity {

    ImageButton btnBack;
    Button btnSave;
    TextView tvOrderInfo;
    RadioGroup rgStatus;
    RadioButton rbNew, rbProgress, rbReady;
    OrderManager orderManager;
    int orderId;
    String currentStatus;
    String deadline;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_status);

        orderManager = new OrderManager(this);
        btnBack = findViewById(R.id.btn_back);
        btnSave = findViewById(R.id.btn_save);
        tvOrderInfo = findViewById(R.id.tv_order_info);
        rgStatus = findViewById(R.id.rg_status);
        rbNew = findViewById(R.id.rb_new);
        rbProgress = findViewById(R.id.rb_progress);
        rbReady = findViewById(R.id.rb_ready);

        Intent intent = getIntent();
        orderId = intent.getIntExtra("order_id", -1);
        currentStatus = intent.getStringExtra("current_status");
        deadline = intent.getStringExtra("deadline");

        tvOrderInfo.setText("Заказ #" + orderId);

        if (currentStatus.equals("НОВЫЙ")) {
            rbNew.setChecked(true);
        } else if (currentStatus.equals("В РАБОТЕ")) {
            rbProgress.setChecked(true);
        } else if (currentStatus.equals("ГОТОВ")) {
            rbReady.setChecked(true);
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveStatus();
            }
        });
    }

    private void saveStatus() {
        String newStatus = "НОВЫЙ";
        if (rbProgress.isChecked()) {
            newStatus = "В РАБОТЕ";
        } else if (rbReady.isChecked()) {
            newStatus = "ГОТОВ";
        }

        List<Order> orders = orderManager.getOrders();
        for (Order order : orders) {
            if (order.id == orderId) {
                order.status = newStatus;
                break;
            }
        }

        orderManager.saveOrders(orders);
        Toast.makeText(this, "Статус изменен на " + newStatus, Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }
}