package com.example.tpkprogram.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.Client;
import com.example.tpkprogram.managers.ClientManager;
import com.example.tpkprogram.R;

import java.util.List;
import java.util.Locale;

public class ClientsActivity extends AppCompatActivity {

    EditText etSearch;
    Button btnSearch, btnAdd;
    ImageButton btnBack;
    LinearLayout clientsContainer;
    ClientManager clientManager;

    private static final int REQUEST_CODE_ADD_EDIT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clients);

        clientManager = new ClientManager(this);
        etSearch = findViewById(R.id.et_search);
        btnSearch = findViewById(R.id.btn_search);
        btnBack = findViewById(R.id.btn_back);
        btnAdd = findViewById(R.id.btn_add);
        clientsContainer = findViewById(R.id.clients_container);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ClientsActivity.this, EditClientActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchClient();
            }
        });

        loadClients();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD_EDIT && resultCode == RESULT_OK) {
            loadClients();
        }
    }

    private void loadClients() {
        clientsContainer.removeAllViews();
        List<Client> clients = clientManager.getClients();
        boolean hasClients = false;

        for (Client client : clients) {
            hasClients = true;
            addClientView(client);
        }

        if (!hasClients) {
            TextView empty = new TextView(this);
            empty.setText("Клиенты не найдены");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            clientsContainer.addView(empty);
        }
    }

    private void addClientView(Client client) {
        View view = getLayoutInflater().inflate(R.layout.item_client, clientsContainer, false);
        TextView tvName = view.findViewById(R.id.tv_name);
        TextView tvContact = view.findViewById(R.id.tv_contact);
        TextView tvPhone = view.findViewById(R.id.tv_phone);
        TextView tvAddress = view.findViewById(R.id.tv_address);
        TextView tvOrders = view.findViewById(R.id.tv_orders);
        ImageButton btnEdit = view.findViewById(R.id.btn_edit);
        ImageButton btnDelete = view.findViewById(R.id.btn_delete);

        tvName.setText(client.name);
        tvContact.setText(client.contactPerson);
        tvPhone.setText(client.phone);
        tvAddress.setText(client.address);
        tvOrders.setText("Заказы: нет");

        final Client finalClient = client;
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ClientsActivity.this, EditClientActivity.class);
                intent.putExtra("id", finalClient.id);
                intent.putExtra("name", finalClient.name);
                intent.putExtra("contactPerson", finalClient.contactPerson);
                intent.putExtra("phone", finalClient.phone);
                intent.putExtra("email", finalClient.email);
                intent.putExtra("address", finalClient.address);
                startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteDialog(finalClient);
            }
        });

        clientsContainer.addView(view);
    }

    private void showDeleteDialog(Client client) {
        new AlertDialog.Builder(this)
                .setTitle("Удаление клиента")
                .setMessage("Вы уверены, что хотите удалить клиента \"" + client.name + "\"?")
                .setPositiveButton("ДА", (dialog, which) -> {
                    List<Client> clients = clientManager.getClients();
                    int idToDelete = client.id;
                    for (int i = 0; i < clients.size(); i++) {
                        if (clients.get(i).id == idToDelete) {
                            clients.remove(i);
                            break;
                        }
                    }
                    clientManager.saveClients(clients);
                    loadClients();
                    Toast.makeText(ClientsActivity.this, "Клиент удален", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("НЕТ", null)
                .show();
    }

    private void searchClient() {
        String searchName = etSearch.getText().toString().trim();
        if (searchName.isEmpty()) {
            loadClients();
            return;
        }

        clientsContainer.removeAllViews();
        List<Client> clients = clientManager.getClients();
        boolean found = false;

        for (Client client : clients) {
            if (client.name.toLowerCase(Locale.getDefault()).contains(searchName.toLowerCase(Locale.getDefault()))) {
                found = true;
                addClientView(client);
            }
        }

        if (!found) {
            TextView empty = new TextView(this);
            empty.setText("Клиент не найден");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            clientsContainer.addView(empty);
        }
    }
}