package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.Client;
import com.example.tpkprogram.managers.ClientManager;
import com.example.tpkprogram.R;

import java.util.List;

public class EditClientActivity extends AppCompatActivity {

    EditText etName, etContactPerson, etPhone, etEmail, etAddress;
    Button btnSave;
    ImageButton btnBack;
    TextView title;
    ClientManager clientManager;
    int originalId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_client);

        clientManager = new ClientManager(this);
        etName = findViewById(R.id.et_name);
        etContactPerson = findViewById(R.id.et_contact_person);
        etPhone = findViewById(R.id.et_phone);
        etEmail = findViewById(R.id.et_email);
        etAddress = findViewById(R.id.et_address);
        btnSave = findViewById(R.id.btn_save);
        btnBack = findViewById(R.id.btn_back);
        title = findViewById(R.id.title);

        Intent intent = getIntent();
        if (intent.hasExtra("id")) {
            originalId = intent.getIntExtra("id", -1);
            etName.setText(intent.getStringExtra("name"));
            etContactPerson.setText(intent.getStringExtra("contactPerson"));
            etPhone.setText(intent.getStringExtra("phone"));
            etEmail.setText(intent.getStringExtra("email"));
            etAddress.setText(intent.getStringExtra("address"));
            title.setText("РЕДАКТИРОВАНИЕ");
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveClient();
            }
        });
    }

    private void saveClient() {
        String name = etName.getText().toString().trim();
        String contactPerson = etContactPerson.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        if (name.isEmpty() || contactPerson.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            Toast.makeText(this, "Заполните обязательные поля (название, ФИО, телефон, адрес)", Toast.LENGTH_SHORT).show();
            return;
        }

        List<Client> clients = clientManager.getClients();

        if (originalId == -1) {
            for (Client c : clients) {
                if (c.name.equals(name)) {
                    Toast.makeText(this, "Клиент с таким названием уже существует", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            int newId = clientManager.getNextId();
            clients.add(new Client(newId, name, contactPerson, phone, email, address));
        } else {
            for (Client c : clients) {
                if (c.id != originalId && c.name.equals(name)) {
                    Toast.makeText(this, "Клиент с таким названием уже существует", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            for (Client c : clients) {
                if (c.id == originalId) {
                    c.name = name;
                    c.contactPerson = contactPerson;
                    c.phone = phone;
                    c.email = email;
                    c.address = address;
                    break;
                }
            }
        }

        clientManager.saveClients(clients);
        setResult(RESULT_OK);
        Toast.makeText(this, "Клиент сохранен", Toast.LENGTH_SHORT).show();
        finish();
    }
}