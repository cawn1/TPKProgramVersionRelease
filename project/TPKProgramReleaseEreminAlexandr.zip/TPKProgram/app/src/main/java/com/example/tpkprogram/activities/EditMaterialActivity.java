package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.Material;
import com.example.tpkprogram.managers.MaterialManager;
import com.example.tpkprogram.R;

import java.util.List;
import java.util.Locale;

public class EditMaterialActivity extends AppCompatActivity {

    EditText etName, etStock, etUnit, etPrice;
    Button btnSave;
    ImageButton btnBack;
    TextView title;
    MaterialManager materialManager;
    String originalName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_material);

        materialManager = new MaterialManager(this);
        etName = findViewById(R.id.et_name);
        etStock = findViewById(R.id.et_stock);
        etUnit = findViewById(R.id.et_unit);
        etPrice = findViewById(R.id.et_price);
        btnSave = findViewById(R.id.btn_save);
        btnBack = findViewById(R.id.btn_back);
        title = findViewById(R.id.title);

        Intent intent = getIntent();
        if (intent.hasExtra("name")) {
            originalName = intent.getStringExtra("name");
            etName.setText(originalName);
            etStock.setText(String.valueOf(intent.getIntExtra("stock", 0)));
            etUnit.setText(intent.getStringExtra("unit"));
            etPrice.setText(String.format(Locale.getDefault(), "%.2f", intent.getDoubleExtra("price", 0.0)));
            title.setText("РЕДАКТИРОВАНИЕ");
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveMaterial();
            }
        });
    }

    private void saveMaterial() {
        String name = etName.getText().toString().trim();
        String stockStr = etStock.getText().toString().trim();
        String unit = etUnit.getText().toString().trim();
        String priceStr = etPrice.getText().toString().trim();

        if (name.isEmpty() || stockStr.isEmpty() || unit.isEmpty() || priceStr.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }

        int stock;
        double price;
        try {
            stock = Integer.parseInt(stockStr);
            price = Double.parseDouble(priceStr.replace(',', '.'));
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Неверный формат числа", Toast.LENGTH_SHORT).show();
            return;
        }

        List<Material> materials = materialManager.getMaterials();

        if (originalName == null) {
            for (Material m : materials) {
                if (m.name.equals(name)) {
                    Toast.makeText(this, "Материал с таким названием уже существует", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            materials.add(new Material(name, stock, unit, price));
        } else {
            if (!originalName.equals(name)) {
                for (Material m : materials) {
                    if (m.name.equals(name)) {
                        Toast.makeText(this, "Материал с таким названием уже существует", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
            }
            for (Material m : materials) {
                if (m.name.equals(originalName)) {
                    m.name = name;
                    m.stock = stock;
                    m.unit = unit;
                    m.price = price;
                    break;
                }
            }
        }

        materialManager.saveMaterials(materials);
        setResult(RESULT_OK);
        Toast.makeText(this, "Материал сохранен", Toast.LENGTH_SHORT).show();
        finish();
    }
}