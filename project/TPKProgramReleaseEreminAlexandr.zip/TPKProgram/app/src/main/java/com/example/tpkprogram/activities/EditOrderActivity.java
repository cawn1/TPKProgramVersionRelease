package com.example.tpkprogram.activities;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tpkprogram.managers.ClientManager;
import com.example.tpkprogram.managers.MaterialManager;
import com.example.tpkprogram.managers.OrderManager;
import com.example.tpkprogram.managers.ProductTypeManager;
import com.example.tpkprogram.managers.UserManager;
import com.example.tpkprogram.models.Client;
import com.example.tpkprogram.models.Material;
import com.example.tpkprogram.models.Order;
import com.example.tpkprogram.models.OrderMaterial;
import com.example.tpkprogram.models.ProductType;
import com.example.tpkprogram.models.User;
import com.example.tpkprogram.R;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class EditOrderActivity extends AppCompatActivity {

    Spinner spinnerClient, spinnerProductType, spinnerOperator;
    EditText etQuantity, etDeadline, etDescription, etLaborCost, etDiscount;
    ImageButton btnBack;
    Button btnSave, btnNewClient, btnAddMaterial;
    TextView title, tvMaterialsList, tvMaterialsTotal, tvMaterialsCostDisplay, tvTotalCost;
    OrderManager orderManager;
    ClientManager clientManager;
    ProductTypeManager productTypeManager;
    MaterialManager materialManager;
    UserManager userManager;
    List<OrderMaterial> selectedMaterials = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_order);

        orderManager = new OrderManager(this);
        clientManager = new ClientManager(this);
        productTypeManager = new ProductTypeManager(this);
        materialManager = new MaterialManager(this);
        userManager = new UserManager(this);

        spinnerClient = findViewById(R.id.spinner_client);
        spinnerProductType = findViewById(R.id.spinner_product_type);
        spinnerOperator = findViewById(R.id.spinner_operator);
        etQuantity = findViewById(R.id.et_quantity);
        etDeadline = findViewById(R.id.et_deadline);
        etDescription = findViewById(R.id.et_description);
        etLaborCost = findViewById(R.id.et_labor_cost);
        etDiscount = findViewById(R.id.et_discount);
        btnBack = findViewById(R.id.btn_back);
        btnSave = findViewById(R.id.btn_save);
        btnNewClient = findViewById(R.id.btn_new_client);
        btnAddMaterial = findViewById(R.id.btn_add_material);
        title = findViewById(R.id.title);
        tvMaterialsList = findViewById(R.id.tv_materials_list);
        tvMaterialsTotal = findViewById(R.id.tv_materials_total);
        tvMaterialsCostDisplay = findViewById(R.id.tv_materials_cost_display);
        tvTotalCost = findViewById(R.id.tv_total_cost);

        loadClients();
        loadProductTypes();
        loadOperators();

        etDeadline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateTimePicker();
            }
        });

        btnNewClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditOrderActivity.this, EditClientActivity.class);
                startActivityForResult(intent, 2);
            }
        });

        btnAddMaterial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditOrderActivity.this, SelectMaterialActivity.class);
                intent.putExtra("selected_materials", (ArrayList<OrderMaterial>) selectedMaterials);
                startActivityForResult(intent, 1);
            }
        });

        etLaborCost.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) updateTotalCost();
            }
        });

        etDiscount.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) updateTotalCost();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveOrder();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK) {
            loadClients();
        } else if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            OrderMaterial material = (OrderMaterial) data.getSerializableExtra("order_material");
            if (material != null) {
                selectedMaterials.add(material);
                updateMaterialsDisplay();
            }
        }
    }

    private void loadClients() {
        List<Client> clients = clientManager.getClients();
        List<String> clientNames = new ArrayList<>();
        for (Client client : clients) {
            clientNames.add(client.name);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, clientNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerClient.setAdapter(adapter);
    }

    private void loadProductTypes() {
        List<ProductType> types = productTypeManager.getProductTypes();
        List<String> typeNames = new ArrayList<>();
        for (ProductType type : types) {
            typeNames.add(type.name);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, typeNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerProductType.setAdapter(adapter);
    }

    private void loadOperators() {
        List<User> users = userManager.getUsers();
        List<String> operatorLogins = new ArrayList<>();
        for (User user : users) {
            if (user.role.equals("operator")) {
                operatorLogins.add(user.login);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, operatorLogins);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOperator.setAdapter(adapter);
    }

    private void showDateTimePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(year, monthOfYear, dayOfMonth);

                        int hour = calendar.get(Calendar.HOUR_OF_DAY);
                        int minute = calendar.get(Calendar.MINUTE);

                        TimePickerDialog timePickerDialog = new TimePickerDialog(EditOrderActivity.this,
                                new TimePickerDialog.OnTimeSetListener() {
                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                                        calendar.set(Calendar.MINUTE, minute);

                                        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
                                        etDeadline.setText(sdf.format(calendar.getTime()));
                                    }
                                }, hour, minute, true);
                        timePickerDialog.show();
                    }
                }, year, month, day);
        datePickerDialog.show();
    }

    private void updateMaterialsDisplay() {
        if (selectedMaterials.isEmpty()) {
            tvMaterialsList.setText("Материалы не добавлены (добавьте)");
            tvMaterialsTotal.setText("Итого материалов: 0 ₽");
            tvMaterialsCostDisplay.setText("0 ₽");
        } else {
            StringBuilder sb = new StringBuilder();
            double totalCost = 0;
            for (OrderMaterial m : selectedMaterials) {
                sb.append(m.name).append(" - ").append(m.quantity).append(" ").append(m.unit).append("\n");
                totalCost += m.price * m.quantity;
            }
            tvMaterialsList.setText(sb.toString().trim());
            tvMaterialsTotal.setText("Итого материалов: " + String.format(Locale.getDefault(), "%.0f", totalCost) + " ₽");
            tvMaterialsCostDisplay.setText(String.format(Locale.getDefault(), "%.0f", totalCost) + " ₽");
        }
        updateTotalCost();
    }

    private void updateTotalCost() {
        double materialsCost = 0;
        for (OrderMaterial m : selectedMaterials) {
            materialsCost += m.price * m.quantity;
        }

        double laborCost = 0;
        try {
            laborCost = Double.parseDouble(etLaborCost.getText().toString());
        } catch (NumberFormatException e) {}

        double discount = 0;
        try {
            discount = Double.parseDouble(etDiscount.getText().toString());
        } catch (NumberFormatException e) {}

        double total = (materialsCost + laborCost) * (1 - discount / 100);
        tvTotalCost.setText(String.format(Locale.getDefault(), "%.0f", total) + " ₽");
    }

    private void saveOrder() {
        String clientName = spinnerClient.getSelectedItem().toString();
        String productType = spinnerProductType.getSelectedItem().toString();
        String quantityStr = etQuantity.getText().toString().trim();
        String deadline = etDeadline.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String operatorLogin = spinnerOperator.getSelectedItem().toString();
        String laborCostStr = etLaborCost.getText().toString().trim();
        String discountStr = etDiscount.getText().toString().trim();

        if (clientName.isEmpty() || productType.isEmpty() || quantityStr.isEmpty() ||
                deadline.isEmpty() || operatorLogin.isEmpty()) {
            Toast.makeText(this, "Заполните все обязательные поля", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedMaterials.isEmpty()) {
            Toast.makeText(this, "Добавьте хотя бы один материал", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        double laborCost = 0;
        double discount = 0;

        try {
            quantity = Integer.parseInt(quantityStr);
            if (quantity <= 0) {
                Toast.makeText(this, "Тираж должен быть больше 0", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Неверный формат тиража", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            laborCost = Double.parseDouble(laborCostStr);
        } catch (NumberFormatException e) {}

        try {
            discount = Double.parseDouble(discountStr);
            if (discount < 0 || discount > 100) {
                Toast.makeText(this, "Скидка должна быть от 0 до 100%", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {}

        double materialsCost = 0;
        for (OrderMaterial m : selectedMaterials) {
            materialsCost += m.price * m.quantity;
        }

        List<Order> orders = orderManager.getOrders();
        int newId = orderManager.getNextId();
        Order order = new Order(newId, clientName, productType, quantity, deadline,
                description, operatorLogin, "НОВЫЙ",
                materialsCost, laborCost, discount);
        order.materials = new ArrayList<>(selectedMaterials);
        orders.add(order);
        orderManager.saveOrders(orders);

        Toast.makeText(this, "Заказ #" + newId + " сохранен", Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }
}