package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.ProductType;
import com.example.tpkprogram.managers.ProductTypeManager;
import com.example.tpkprogram.R;

import java.util.List;

public class EditProductTypeActivity extends AppCompatActivity {

    EditText etName, etDescription;
    Button btnSave;
    ImageButton btnBack;
    TextView title;
    ProductTypeManager typeManager;
    int originalId = -1;
    String originalName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product_type);

        typeManager = new ProductTypeManager(this);
        etName = findViewById(R.id.et_name);
        etDescription = findViewById(R.id.et_description);
        btnSave = findViewById(R.id.btn_save);
        btnBack = findViewById(R.id.btn_back);
        title = findViewById(R.id.title);

        Intent intent = getIntent();
        if (intent.hasExtra("id")) {
            originalId = intent.getIntExtra("id", -1);
            originalName = intent.getStringExtra("name");
            etName.setText(originalName);
            etDescription.setText(intent.getStringExtra("description"));
            title.setText("РЕДАКТИРОВАНИЕ");
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveType();
            }
        });
    }

    private void saveType() {
        String name = etName.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (name.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }

        List<ProductType> types = typeManager.getProductTypes();

        if (originalId == -1) {
            for (ProductType t : types) {
                if (t.name.equals(name)) {
                    Toast.makeText(this, "Тип продукции с таким названием уже существует", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            int newId = typeManager.getNextId();
            types.add(new ProductType(newId, name, description));
        } else {
            for (ProductType t : types) {
                if (t.id != originalId && t.name.equals(name)) {
                    Toast.makeText(this, "Тип продукции с таким названием уже существует", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            for (ProductType t : types) {
                if (t.id == originalId) {
                    t.name = name;
                    t.description = description;
                    break;
                }
            }
        }

        typeManager.saveProductTypes(types);
        setResult(RESULT_OK);
        Toast.makeText(this, "Тип продукции сохранен", Toast.LENGTH_SHORT).show();
        finish();
    }
}