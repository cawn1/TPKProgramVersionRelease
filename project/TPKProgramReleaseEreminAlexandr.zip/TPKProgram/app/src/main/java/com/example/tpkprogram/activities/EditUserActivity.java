package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.R;
import com.example.tpkprogram.models.User;
import com.example.tpkprogram.managers.UserManager;

import java.util.List;

public class EditUserActivity extends AppCompatActivity {

    EditText etLogin, etPassword;
    Spinner spinnerRole;
    Button btnSave;
    ImageButton btnBack;
    TextView title;
    UserManager userManager;
    String originalLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        userManager = new UserManager(this);
        etLogin = findViewById(R.id.et_login);
        etPassword = findViewById(R.id.et_password);
        spinnerRole = findViewById(R.id.spinner_role);
        btnSave = findViewById(R.id.btn_save);
        btnBack = findViewById(R.id.btn_back);
        title = findViewById(R.id.title);

        String[] roles = {"Администратор", "Менеджер", "Оператор"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, roles);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRole.setAdapter(adapter);

        Intent intent = getIntent();
        if (intent.hasExtra("login")) {
            originalLogin = intent.getStringExtra("login");
            etLogin.setText(originalLogin);
            etPassword.setText(intent.getStringExtra("password"));
            String role = intent.getStringExtra("role");
            spinnerRole.setSelection(getRolePosition(role));
            title.setText("РЕДАКТИРОВАНИЕ");
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUser();
            }
        });
    }

    private int getRolePosition(String role) {
        switch (role) {
            case "admin": return 0;
            case "manager": return 1;
            case "operator": return 2;
            default: return 0;
        }
    }

    private void saveUser() {
        String login = etLogin.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String role = getRoleFromPosition(spinnerRole.getSelectedItemPosition());

        if (login.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }

        List<User> users = userManager.getUsers();

        if (originalLogin == null) {
            for (User u : users) {
                if (u.login.equals(login)) {
                    Toast.makeText(this, "Пользователь с таким логином уже существует", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            users.add(new User(login, password, role));
        } else {
            if (!originalLogin.equals(login)) {
                for (User u : users) {
                    if (u.login.equals(login)) {
                        Toast.makeText(this, "Пользователь с таким логином уже существует", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
            }
            for (User u : users) {
                if (u.login.equals(originalLogin)) {
                    u.login = login;
                    u.password = password;
                    u.role = role;
                    break;
                }
            }
        }

        userManager.saveUsers(users);
        setResult(RESULT_OK);
        Toast.makeText(this, "Пользователь сохранен", Toast.LENGTH_SHORT).show();
        finish();
    }

    private String getRoleFromPosition(int position) {
        switch (position) {
            case 0: return "admin";
            case 1: return "manager";
            case 2: return "operator";
            default: return "operator";
        }
    }
}