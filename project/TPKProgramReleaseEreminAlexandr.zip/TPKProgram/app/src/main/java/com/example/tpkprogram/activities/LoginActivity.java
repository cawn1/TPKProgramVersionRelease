package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.R;
import com.example.tpkprogram.models.User;
import com.example.tpkprogram.managers.UserManager;

public class LoginActivity extends AppCompatActivity {

    EditText etLogin, etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etLogin = findViewById(R.id.et_login);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = etLogin.getText().toString();
                String password = etPassword.getText().toString();

                UserManager userManager = new UserManager(LoginActivity.this);
                User user = userManager.authenticate(login, password);

                if (user != null) {
                    if (user.role.equals("admin")) {
                        startActivity(new Intent(LoginActivity.this, AdminMainActivity.class));
                    } else if (user.role.equals("manager")) {
                        startActivity(new Intent(LoginActivity.this, ManagerMainActivity.class));
                    } else if (user.role.equals("operator")) {
                        Intent intent = new Intent(LoginActivity.this, OperatorMainActivity.class);
                        intent.putExtra("operator_login", user.login);
                        startActivity(intent);
                    }
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}