package com.example.tpkprogram.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.OrderMaterial;
import com.example.tpkprogram.R;

import java.util.List;
import java.util.Locale;

public class MaterialAccountingActivity extends AppCompatActivity {

    ImageButton btnBack;
    TextView tvOrderNumber;
    LinearLayout materialsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material_accounting);

        btnBack = findViewById(R.id.btn_back);
        tvOrderNumber = findViewById(R.id.tv_order_number);
        materialsContainer = findViewById(R.id.materials_container);

        int orderId = getIntent().getIntExtra("order_id", -1);
        tvOrderNumber.setText("Заказ #" + orderId);

        @SuppressWarnings("unchecked")
        List<OrderMaterial> materials = (List<OrderMaterial>) getIntent().getSerializableExtra("materials");

        if (materials == null || materials.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Материалы не добавлены");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            materialsContainer.addView(empty);
        } else {
            for (OrderMaterial material : materials) {
                addMaterialView(material);
            }
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void addMaterialView(OrderMaterial material) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);
        layout.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
        layout.setElevation(2);
        layout.setPadding(16, 16, 16, 16);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        TextView tvName = new TextView(this);
        tvName.setText(material.name);
        tvName.setTextSize(18);
        tvName.setTextColor(0xFF263238);
        tvName.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView tvQuantity = new TextView(this);
        tvQuantity.setText("Количество: " + material.quantity + " " + material.unit);
        tvQuantity.setTextSize(16);
        tvQuantity.setTextColor(0xFF546E7A);
        tvQuantity.setPadding(0, 4, 0, 0);

        TextView tvPrice = new TextView(this);
        tvPrice.setText("Цена за единицу: " + String.format(Locale.getDefault(), "%.2f", material.price) + " ₽");
        tvPrice.setTextSize(16);
        tvPrice.setTextColor(0xFFFF9800);
        tvPrice.setPadding(0, 4, 0, 0);

        TextView tvTotal = new TextView(this);
        double total = material.price * material.quantity;
        tvTotal.setText("Итого: " + String.format(Locale.getDefault(), "%.0f", total) + " ₽");
        tvTotal.setTextSize(16);
        tvTotal.setTextColor(0xFF4CAF50);
        tvTotal.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTotal.setPadding(0, 8, 0, 0);

        layout.addView(tvName);
        layout.addView(tvQuantity);
        layout.addView(tvPrice);
        layout.addView(tvTotal);

        materialsContainer.addView(layout);

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));
        divider.setBackgroundColor(0xFFE0E0E0);
        divider.setPadding(0, 16, 0, 16);
        materialsContainer.addView(divider);
    }
}