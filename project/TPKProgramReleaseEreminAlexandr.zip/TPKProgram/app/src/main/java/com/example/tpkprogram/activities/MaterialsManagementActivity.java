package com.example.tpkprogram.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.Material;
import com.example.tpkprogram.managers.MaterialManager;
import com.example.tpkprogram.R;

import java.util.List;
import java.util.Locale;

public class MaterialsManagementActivity extends AppCompatActivity {

    EditText etSearch;
    Button btnSearch, btnAdd;
    ImageButton btnBack;
    LinearLayout materialsContainer;
    MaterialManager materialManager;

    private static final int REQUEST_CODE_ADD_EDIT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materials_management);

        materialManager = new MaterialManager(this);
        etSearch = findViewById(R.id.et_search);
        btnSearch = findViewById(R.id.btn_search);
        btnBack = findViewById(R.id.btn_back);
        btnAdd = findViewById(R.id.btn_add);
        materialsContainer = findViewById(R.id.materials_container);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MaterialsManagementActivity.this, EditMaterialActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchMaterial();
            }
        });

        loadMaterials();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD_EDIT && resultCode == RESULT_OK) {
            loadMaterials();
        }
    }

    private void loadMaterials() {
        materialsContainer.removeAllViews();
        List<Material> materials = materialManager.getMaterials();
        boolean hasMaterials = false;

        for (Material material : materials) {
            hasMaterials = true;
            addMaterialView(material);
        }

        if (!hasMaterials) {
            TextView empty = new TextView(this);
            empty.setText("Материалы не найдены");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            materialsContainer.addView(empty);
        }
    }

    private void addMaterialView(Material material) {
        View view = getLayoutInflater().inflate(R.layout.item_material, materialsContainer, false);
        TextView tvName = view.findViewById(R.id.tv_name);
        TextView tvStock = view.findViewById(R.id.tv_stock);
        TextView tvPrice = view.findViewById(R.id.tv_price);
        ImageButton btnEdit = view.findViewById(R.id.btn_edit);
        ImageButton btnDelete = view.findViewById(R.id.btn_delete);

        tvName.setText(material.name);
        tvStock.setText("Остаток: " + material.stock + " " + material.unit);
        tvPrice.setText("Цена: " + String.format(Locale.getDefault(), "%.2f", material.price) + " ₽");

        final Material finalMaterial = material;
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MaterialsManagementActivity.this, EditMaterialActivity.class);
                intent.putExtra("name", finalMaterial.name);
                intent.putExtra("stock", finalMaterial.stock);
                intent.putExtra("unit", finalMaterial.unit);
                intent.putExtra("price", finalMaterial.price);
                startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteDialog(finalMaterial);
            }
        });

        materialsContainer.addView(view);
    }

    private void showDeleteDialog(Material material) {
        new AlertDialog.Builder(this)
                .setTitle("Удаление материала")
                .setMessage("Вы уверены, что хотите удалить материал " + material.name + "?")
                .setPositiveButton("ДА", (dialog, which) -> {
                    List<Material> materials = materialManager.getMaterials();
                    String nameToDelete = material.name;
                    for (int i = 0; i < materials.size(); i++) {
                        if (materials.get(i).name.equals(nameToDelete)) {
                            materials.remove(i);
                            break;
                        }
                    }
                    materialManager.saveMaterials(materials);
                    loadMaterials();
                    Toast.makeText(MaterialsManagementActivity.this, "Материал удален", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("НЕТ", null)
                .show();
    }

    private void searchMaterial() {
        String searchName = etSearch.getText().toString().trim();
        if (searchName.isEmpty()) {
            loadMaterials();
            return;
        }

        materialsContainer.removeAllViews();
        List<Material> materials = materialManager.getMaterials();
        boolean found = false;

        for (Material material : materials) {
            if (material.name.toLowerCase(Locale.getDefault()).contains(searchName.toLowerCase(Locale.getDefault()))) {
                found = true;
                addMaterialView(material);
            }
        }

        if (!found) {
            TextView empty = new TextView(this);
            empty.setText("Материал не найден");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            materialsContainer.addView(empty);
        }
    }
}