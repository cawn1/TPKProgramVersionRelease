package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.R;

public class OperatorMainActivity extends AppCompatActivity {

    Button btnOrders, btnLogout;
    String operatorLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operator_main);

        operatorLogin = getIntent().getStringExtra("operator_login");

        btnOrders = findViewById(R.id.btn_orders);
        btnLogout = findViewById(R.id.btn_logout);

        btnOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OperatorMainActivity.this, OperatorOrdersActivity.class);
                intent.putExtra("operator_login", operatorLogin);
                startActivity(intent);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(OperatorMainActivity.this, LoginActivity.class));
                finish();
            }
        });
    }
}