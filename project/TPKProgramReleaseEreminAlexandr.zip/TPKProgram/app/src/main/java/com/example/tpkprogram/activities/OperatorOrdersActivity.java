package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.Order;
import com.example.tpkprogram.managers.OrderManager;
import com.example.tpkprogram.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class OperatorOrdersActivity extends AppCompatActivity {

    ImageButton btnBack;
    LinearLayout ordersContainer;
    OrderManager orderManager;
    String operatorLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operator_orders);

        orderManager = new OrderManager(this);
        operatorLogin = getIntent().getStringExtra("operator_login");

        btnBack = findViewById(R.id.btn_back);
        ordersContainer = findViewById(R.id.orders_container);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        loadOrders();
    }

    private void loadOrders() {
        ordersContainer.removeAllViews();
        List<Order> orders = orderManager.getOrders();
        boolean hasOrders = false;

        for (Order order : orders) {
            if (order.operatorLogin.equals(operatorLogin)) {
                hasOrders = true;
                addOrderView(order);
            }
        }

        if (!hasOrders) {
            TextView empty = new TextView(this);
            empty.setText("У вас нет заказов");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            ordersContainer.addView(empty);
        }
    }

    private void addOrderView(Order order) {
        View view = getLayoutInflater().inflate(R.layout.item_operator_order, ordersContainer, false);
        TextView tvOrderNumber = view.findViewById(R.id.tv_order_number);
        TextView tvDates = view.findViewById(R.id.tv_dates);
        TextView tvStatus = view.findViewById(R.id.tv_status);
        TextView tvClient = view.findViewById(R.id.tv_client);
        TextView tvType = view.findViewById(R.id.tv_type);
        TextView tvQuantity = view.findViewById(R.id.tv_quantity);
        TextView tvCost = view.findViewById(R.id.tv_cost);
        View btnChangeStatus = view.findViewById(R.id.btn_change_status);
        View btnMaterials = view.findViewById(R.id.btn_materials);

        tvOrderNumber.setText("Заказ #" + order.id);
        tvDates.setText("Создан: " + getCurrentDateTime() + " | Срок: " + order.deadline);

        String statusText = order.status;
        int statusColor = 0xFF2196F3;
        int statusBgColor = 0x332196F3;

        if (isOverdue(order)) {
            statusText = "ПРОСРОЧЕН";
            statusColor = 0xFFF44336;
            statusBgColor = 0x33F44336;
        } else if (order.status.equals("В РАБОТЕ")) {
            statusColor = 0xFFFF9800;
            statusBgColor = 0x33FF9800;
        } else if (order.status.equals("ГОТОВ")) {
            statusColor = 0xFF4CAF50;
            statusBgColor = 0x334CAF50;
        }

        tvStatus.setText(statusText);
        tvStatus.setTextColor(statusColor);
        tvStatus.setBackgroundColor(statusBgColor);

        tvClient.setText(order.clientName);
        tvType.setText("Тип: " + order.productType);
        tvQuantity.setText("Тираж: " + order.quantity + " шт.");
        double total = (order.materialsCost + order.laborCost) * (1 - order.discountPercent / 100);
        tvCost.setText("Стоимость: " + String.format("%.0f", total) + " ₽");

        final Order finalOrder = order;
        btnChangeStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OperatorOrdersActivity.this, ChangeStatusActivity.class);
                intent.putExtra("order_id", finalOrder.id);
                intent.putExtra("current_status", finalOrder.status);
                intent.putExtra("deadline", finalOrder.deadline);
                startActivityForResult(intent, 1);
            }
        });

        btnMaterials.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OperatorOrdersActivity.this, MaterialAccountingActivity.class);
                intent.putExtra("order_id", finalOrder.id);
                intent.putExtra("materials", (java.io.Serializable) finalOrder.materials);
                startActivity(intent);
            }
        });

        ordersContainer.addView(view);
    }

    private String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
        return sdf.format(Calendar.getInstance().getTime());
    }

    private boolean isOverdue(Order order) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
            Date deadline = sdf.parse(order.deadline);
            Date now = Calendar.getInstance().getTime();
            return now.after(deadline) && !order.status.equals("ГОТОВ");
        } catch (ParseException e) {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            loadOrders();
        }
    }
}