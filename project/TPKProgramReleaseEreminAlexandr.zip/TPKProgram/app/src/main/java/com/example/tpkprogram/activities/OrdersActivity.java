package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.Order;
import com.example.tpkprogram.managers.OrderManager;
import com.example.tpkprogram.R;

import java.util.List;

public class OrdersActivity extends AppCompatActivity {

    ImageButton btnBack;
    Button btnAdd, btnFilterAll, btnFilterNew, btnFilterProgress, btnFilterReady, btnFilterOverdue;
    LinearLayout ordersContainer;
    OrderManager orderManager;
    String currentFilter = "all";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        orderManager = new OrderManager(this);
        btnBack = findViewById(R.id.btn_back);
        btnAdd = findViewById(R.id.btn_add);
        btnFilterAll = findViewById(R.id.btn_filter_all);
        btnFilterNew = findViewById(R.id.btn_filter_new);
        btnFilterProgress = findViewById(R.id.btn_filter_progress);
        btnFilterReady = findViewById(R.id.btn_filter_ready);
        btnFilterOverdue = findViewById(R.id.btn_filter_overdue);
        ordersContainer = findViewById(R.id.orders_container);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OrdersActivity.this, EditOrderActivity.class);
                startActivityForResult(intent, 1);
            }
        });

        btnFilterAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "all";
                loadOrders();
            }
        });

        btnFilterNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "new";
                loadOrders();
            }
        });

        btnFilterProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "progress";
                loadOrders();
            }
        });

        btnFilterReady.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "ready";
                loadOrders();
            }
        });

        btnFilterOverdue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "overdue";
                loadOrders();
            }
        });

        loadOrders();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            loadOrders();
        }
    }

    private void loadOrders() {
        ordersContainer.removeAllViews();
        List<Order> orders = orderManager.getOrders();
        boolean hasOrders = false;

        for (Order order : orders) {
            if (currentFilter.equals("all") ||
                    (currentFilter.equals("new") && order.status.equals("НОВЫЙ")) ||
                    (currentFilter.equals("progress") && order.status.equals("В РАБОТЕ")) ||
                    (currentFilter.equals("ready") && order.status.equals("ГОТОВ")) ||
                    (currentFilter.equals("overdue") && order.status.equals("ПРОСРОЧЕН"))) {

                hasOrders = true;
                addOrderView(order);
            }
        }

        if (!hasOrders) {
            TextView empty = new TextView(this);
            empty.setText("Заказы не найдены");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            ordersContainer.addView(empty);
        }
    }

    private void addOrderView(Order order) {
        View view = getLayoutInflater().inflate(R.layout.item_order, ordersContainer, false);
        TextView tvOrderNumber = view.findViewById(R.id.tv_order_number);
        TextView tvClient = view.findViewById(R.id.tv_client);
        TextView tvType = view.findViewById(R.id.tv_type);
        TextView tvQuantity = view.findViewById(R.id.tv_quantity);
        TextView tvDeadline = view.findViewById(R.id.tv_deadline);
        TextView tvCost = view.findViewById(R.id.tv_cost);
        TextView tvStatus = view.findViewById(R.id.tv_status);

        tvOrderNumber.setText("Заказ #" + order.id);
        tvClient.setText(order.clientName);
        tvType.setText("Тип: " + order.productType);
        tvQuantity.setText("Тираж: " + order.quantity + " шт.");
        tvDeadline.setText("Срок: " + order.deadline);
        double total = (order.materialsCost + order.laborCost) * (1 - order.discountPercent / 100);
        tvCost.setText("Стоимость: " + String.format("%.0f", total) + " ₽");
        tvStatus.setText(order.status);

        if (order.status.equals("НОВЫЙ")) {
            tvStatus.setTextColor(0xFF2196F3);
            tvStatus.setBackgroundColor(0x332196F3);
        } else if (order.status.equals("В РАБОТЕ")) {
            tvStatus.setTextColor(0xFFFF9800);
            tvStatus.setBackgroundColor(0x33FF9800);
        } else if (order.status.equals("ГОТОВ")) {
            tvStatus.setTextColor(0xFF4CAF50);
            tvStatus.setBackgroundColor(0x334CAF50);
        } else if (order.status.equals("ПРОСРОЧЕН")) {
            tvStatus.setTextColor(0xFFF44336);
            tvStatus.setBackgroundColor(0x33F44336);
        }

        ordersContainer.addView(view);
    }
}