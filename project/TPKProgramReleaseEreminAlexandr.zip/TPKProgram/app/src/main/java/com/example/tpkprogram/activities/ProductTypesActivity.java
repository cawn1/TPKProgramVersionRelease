package com.example.tpkprogram.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.ProductType;
import com.example.tpkprogram.managers.ProductTypeManager;
import com.example.tpkprogram.R;

import java.util.List;
import java.util.Locale;

public class ProductTypesActivity extends AppCompatActivity {

    EditText etSearch;
    Button btnSearch, btnAdd;
    ImageButton btnBack;
    LinearLayout typesContainer;
    ProductTypeManager typeManager;

    private static final int REQUEST_CODE_ADD_EDIT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_types);

        typeManager = new ProductTypeManager(this);
        etSearch = findViewById(R.id.et_search);
        btnSearch = findViewById(R.id.btn_search);
        btnBack = findViewById(R.id.btn_back);
        btnAdd = findViewById(R.id.btn_add);
        typesContainer = findViewById(R.id.types_container);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProductTypesActivity.this, EditProductTypeActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchType();
            }
        });

        loadTypes();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD_EDIT && resultCode == RESULT_OK) {
            loadTypes();
        }
    }

    private void loadTypes() {
        typesContainer.removeAllViews();
        List<ProductType> types = typeManager.getProductTypes();
        boolean hasTypes = false;

        for (ProductType type : types) {
            hasTypes = true;
            addTypeView(type);
        }

        if (!hasTypes) {
            TextView empty = new TextView(this);
            empty.setText("Типы продукции не найдены");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            typesContainer.addView(empty);
        }
    }

    private void addTypeView(ProductType type) {
        View view = getLayoutInflater().inflate(R.layout.item_product_type, typesContainer, false);
        TextView tvName = view.findViewById(R.id.tv_name);
        TextView tvId = view.findViewById(R.id.tv_id);
        TextView tvDescription = view.findViewById(R.id.tv_description);
        ImageButton btnEdit = view.findViewById(R.id.btn_edit);
        ImageButton btnDelete = view.findViewById(R.id.btn_delete);

        tvName.setText(type.name);
        tvId.setText("ID: " + type.id);
        tvDescription.setText(type.description);

        final ProductType finalType = type;
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProductTypesActivity.this, EditProductTypeActivity.class);
                intent.putExtra("id", finalType.id);
                intent.putExtra("name", finalType.name);
                intent.putExtra("description", finalType.description);
                startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteDialog(finalType);
            }
        });

        typesContainer.addView(view);
    }

    private void showDeleteDialog(ProductType type) {
        new AlertDialog.Builder(this)
                .setTitle("Удаление типа продукции")
                .setMessage("Вы уверены, что хотите удалить тип продукции \"" + type.name + "\"?")
                .setPositiveButton("ДА", (dialog, which) -> {
                    List<ProductType> types = typeManager.getProductTypes();
                    int idToDelete = type.id;
                    for (int i = 0; i < types.size(); i++) {
                        if (types.get(i).id == idToDelete) {
                            types.remove(i);
                            break;
                        }
                    }
                    typeManager.saveProductTypes(types);
                    loadTypes();
                    Toast.makeText(ProductTypesActivity.this, "Тип продукции удален", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("НЕТ", null)
                .show();
    }

    private void searchType() {
        String searchName = etSearch.getText().toString().trim();
        if (searchName.isEmpty()) {
            loadTypes();
            return;
        }

        typesContainer.removeAllViews();
        List<ProductType> types = typeManager.getProductTypes();
        boolean found = false;

        for (ProductType type : types) {
            if (type.name.toLowerCase(Locale.getDefault()).contains(searchName.toLowerCase(Locale.getDefault()))) {
                found = true;
                addTypeView(type);
            }
        }

        if (!found) {
            TextView empty = new TextView(this);
            empty.setText("Тип продукции не найден");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            typesContainer.addView(empty);
        }
    }
}