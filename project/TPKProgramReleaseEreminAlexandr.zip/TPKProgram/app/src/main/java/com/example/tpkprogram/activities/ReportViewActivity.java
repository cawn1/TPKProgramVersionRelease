package com.example.tpkprogram.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tpkprogram.models.Order;
import com.example.tpkprogram.R;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Locale;

public class ReportViewActivity extends AppCompatActivity {

    ImageButton btnBack;
    Button btnExport;
    TextView tvReportHeader, tvReportPeriod, tvReportCount;
    LinearLayout ordersContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_view);

        btnBack = findViewById(R.id.btn_back);
        btnExport = findViewById(R.id.btn_export);
        tvReportHeader = findViewById(R.id.tv_report_header);
        tvReportPeriod = findViewById(R.id.tv_report_period);
        tvReportCount = findViewById(R.id.tv_report_count);
        ordersContainer = findViewById(R.id.orders_container);

        String reportType = getIntent().getStringExtra("report_type");
        String startDate = getIntent().getStringExtra("start_date");
        String endDate = getIntent().getStringExtra("end_date");
        int ordersCount = getIntent().getIntExtra("orders_count", 0);

        tvReportHeader.setText(reportType);
        tvReportPeriod.setText("Период: " + startDate + " - " + endDate);
        tvReportCount.setText("Найдено заказов: " + ordersCount);

        @SuppressWarnings("unchecked")
        List<Order> orders = (List<Order>) getIntent().getSerializableExtra("orders");

        if (orders != null && !orders.isEmpty()) {
            for (Order order : orders) {
                addOrderView(order);
            }
        } else {
            TextView empty = new TextView(this);
            empty.setText("Нет данных для отображения");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            ordersContainer.addView(empty);
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ReportViewActivity.this, "Экспорт в разработке", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addOrderView(Order order) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
        layout.setPadding(16, 16, 16, 16);
        layout.setElevation(2);

        TextView tvOrderNumber = new TextView(this);
        tvOrderNumber.setText("Заказ #" + order.id);
        tvOrderNumber.setTextSize(18);
        tvOrderNumber.setTextColor(0xFF1A237E);
        tvOrderNumber.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView tvClient = new TextView(this);
        tvClient.setText("Клиент: " + order.clientName);
        tvClient.setTextSize(16);
        tvClient.setTextColor(0xFF263238);
        tvClient.setPadding(0, 4, 0, 0);

        TextView tvType = new TextView(this);
        tvType.setText("Тип: " + order.productType);
        tvType.setTextSize(16);
        tvType.setTextColor(0xFF546E7A);
        tvType.setPadding(0, 2, 0, 0);

        TextView tvQuantity = new TextView(this);
        tvQuantity.setText("Тираж: " + order.quantity + " шт.");
        tvQuantity.setTextSize(16);
        tvQuantity.setTextColor(0xFF546E7A);
        tvQuantity.setPadding(0, 2, 0, 0);

        TextView tvDeadline = new TextView(this);
        tvDeadline.setText("Срок: " + order.deadline);
        tvDeadline.setTextSize(16);
        tvDeadline.setTextColor(0xFFF44336);
        tvDeadline.setPadding(0, 2, 0, 0);

        TextView tvStatus = new TextView(this);
        tvStatus.setText("Статус: " + order.status);
        tvStatus.setTextSize(16);
        tvStatus.setTextColor(getStatusColor(order.status));
        tvStatus.setTypeface(null, android.graphics.Typeface.BOLD);
        tvStatus.setPadding(0, 4, 0, 0);

        TextView tvCost = new TextView(this);
        double total = (order.materialsCost + order.laborCost) * (1 - order.discountPercent / 100);
        DecimalFormat df = new DecimalFormat("#,##0");
        tvCost.setText("Стоимость: " + df.format(total) + " ₽");
        tvCost.setTextSize(16);
        tvCost.setTextColor(0xFF4CAF50);
        tvCost.setTypeface(null, android.graphics.Typeface.BOLD);
        tvCost.setPadding(0, 4, 0, 0);

        layout.addView(tvOrderNumber);
        layout.addView(tvClient);
        layout.addView(tvType);
        layout.addView(tvQuantity);
        layout.addView(tvDeadline);
        layout.addView(tvStatus);
        layout.addView(tvCost);

        ordersContainer.addView(layout);

        View divider = new View(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1);
        params.setMargins(0, 16, 0, 16);
        divider.setLayoutParams(params);
        divider.setBackgroundColor(0xFFE0E0E0);
        ordersContainer.addView(divider);
    }

    private int getStatusColor(String status) {
        switch (status) {
            case "НОВЫЙ": return 0xFF2196F3;
            case "В РАБОТЕ": return 0xFFFF9800;
            case "ГОТОВ": return 0xFF4CAF50;
            case "ПРОСРОЧЕН": return 0xFFF44336;
            default: return 0xFF546E7A;
        }
    }
}