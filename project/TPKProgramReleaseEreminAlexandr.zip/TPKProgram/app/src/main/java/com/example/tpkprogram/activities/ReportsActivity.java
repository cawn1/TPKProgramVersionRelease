package com.example.tpkprogram.activities;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tpkprogram.managers.OrderManager;
import com.example.tpkprogram.models.Order;
import com.example.tpkprogram.R;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class ReportsActivity extends AppCompatActivity {

    ImageButton btnBack;
    EditText etStartDate, etEndDate;
    Spinner spinnerReportType;
    Button btnGenerate;
    OrderManager orderManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        orderManager = new OrderManager(this);
        btnBack = findViewById(R.id.btn_back);
        etStartDate = findViewById(R.id.et_start_date);
        etEndDate = findViewById(R.id.et_end_date);
        spinnerReportType = findViewById(R.id.spinner_report_type);
        btnGenerate = findViewById(R.id.btn_generate);

        setupDatePickers();
        setupReportTypes();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateReport();
            }
        });
    }

    private void setupDatePickers() {
        etStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker(etStartDate);
            }
        });

        etEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker(etEndDate);
            }
        });

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        etStartDate.setText(sdf.format(calendar.getTime()));
        calendar.add(Calendar.MONTH, 1);
        etEndDate.setText(sdf.format(calendar.getTime()));
    }

    private void showDatePicker(final EditText editText) {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(year, monthOfYear, dayOfMonth);
                        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
                        editText.setText(sdf.format(calendar.getTime()));
                    }
                }, year, month, day);
        datePickerDialog.show();
    }

    private void setupReportTypes() {
        List<String> reportTypes = new ArrayList<>();
        reportTypes.add("Все заказы за период");
        reportTypes.add("Заказы по статусу");
        reportTypes.add("Заказы по оператору");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, reportTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerReportType.setAdapter(adapter);
    }

    private void generateReport() {
        String startDateStr = etStartDate.getText().toString().trim();
        String endDateStr = etEndDate.getText().toString().trim();

        if (startDateStr.isEmpty() || endDateStr.isEmpty()) {
            return;
        }

        List<Order> orders = orderManager.getOrders();
        List<Order> filteredOrders = new ArrayList<>();

        for (Order order : orders) {
            if (isOrderInPeriod(order.deadline, startDateStr, endDateStr)) {
                filteredOrders.add(order);
            }
        }

        Intent intent = new Intent(ReportsActivity.this, ReportViewActivity.class);
        intent.putExtra("report_type", spinnerReportType.getSelectedItem().toString());
        intent.putExtra("start_date", startDateStr);
        intent.putExtra("end_date", endDateStr);
        intent.putExtra("orders_count", filteredOrders.size());
        intent.putExtra("orders", (java.io.Serializable) filteredOrders);
        startActivity(intent);
    }

    private boolean isOrderInPeriod(String orderDeadline, String startDateStr, String endDateStr) {
        try {
            SimpleDateFormat sdfDate = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
            SimpleDateFormat sdfDateTime = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());

            String orderDateStr = orderDeadline.substring(0, 10);
            java.util.Date orderDate = sdfDate.parse(orderDateStr);
            java.util.Date startDate = sdfDate.parse(startDateStr);
            java.util.Date endDate = sdfDate.parse(endDateStr);

            return !orderDate.before(startDate) && !orderDate.after(endDate);
        } catch (Exception e) {
            return false;
        }
    }
}