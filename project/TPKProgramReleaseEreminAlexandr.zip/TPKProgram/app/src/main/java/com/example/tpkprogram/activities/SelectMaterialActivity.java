package com.example.tpkprogram.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.models.Material;
import com.example.tpkprogram.managers.MaterialManager;
import com.example.tpkprogram.models.OrderMaterial;
import com.example.tpkprogram.R;

import java.util.ArrayList;
import java.util.List;

public class SelectMaterialActivity extends AppCompatActivity {

    Spinner spinnerMaterial;
    EditText etQuantity;
    TextView tvStockInfo, tvPriceInfo;
    ImageButton btnBack;
    Button btnAdd;
    MaterialManager materialManager;
    List<Material> materials;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_material);

        materialManager = new MaterialManager(this);
        materials = materialManager.getMaterials();

        spinnerMaterial = findViewById(R.id.spinner_material);
        etQuantity = findViewById(R.id.et_quantity);
        tvStockInfo = findViewById(R.id.tv_stock_info);
        tvPriceInfo = findViewById(R.id.tv_price_info);
        btnBack = findViewById(R.id.btn_back);
        btnAdd = findViewById(R.id.btn_add);

        List<String> materialNames = new ArrayList<>();
        for (Material m : materials) {
            materialNames.add(m.name);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, materialNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMaterial.setAdapter(adapter);

        spinnerMaterial.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                updateMaterialInfo();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        updateMaterialInfo();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMaterial();
            }
        });
    }

    private void updateMaterialInfo() {
        int position = spinnerMaterial.getSelectedItemPosition();
        if (position >= 0 && position < materials.size()) {
            Material material = materials.get(position);
            tvStockInfo.setText("Доступно: " + material.stock + " " + material.unit);
            tvPriceInfo.setText("Цена за единицу: " + String.format("%.2f", material.price) + " ₽");
        }
    }

    private void addMaterial() {
        int position = spinnerMaterial.getSelectedItemPosition();
        if (position < 0 || position >= materials.size()) {
            Toast.makeText(this, "Выберите материал", Toast.LENGTH_SHORT).show();
            return;
        }

        String quantityStr = etQuantity.getText().toString().trim();
        if (quantityStr.isEmpty()) {
            Toast.makeText(this, "Введите количество", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Неверный формат количества", Toast.LENGTH_SHORT).show();
            return;
        }

        Material material = materials.get(position);
        if (quantity <= 0) {
            Toast.makeText(this, "Количество должно быть больше 0", Toast.LENGTH_SHORT).show();
            return;
        }

        if (quantity > material.stock) {
            Toast.makeText(this, "Недостаточно материала на складе. Доступно: " + material.stock + " " + material.unit, Toast.LENGTH_SHORT).show();
            return;
        }

        OrderMaterial orderMaterial = new OrderMaterial(
                material.name,
                quantity,
                material.unit,
                material.price
        );

        Intent result = new Intent();
        result.putExtra("order_material", orderMaterial);
        setResult(RESULT_OK, result);
        finish();
    }
}