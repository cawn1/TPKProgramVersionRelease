package com.example.tpkprogram.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.R;
import com.example.tpkprogram.models.User;
import com.example.tpkprogram.managers.UserManager;

import java.util.List;

public class UsersActivity extends AppCompatActivity {

    EditText etLogin, etPassword;
    Spinner spinnerRole;
    Button btnAdd;
    UserManager userManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.irrelevant_activity_users);

        userManager = new UserManager(this);
        etLogin = findViewById(R.id.et_login);
        etPassword = findViewById(R.id.et_password);
        spinnerRole = findViewById(R.id.spinner_role);
        btnAdd = findViewById(R.id.btn_add);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRole.setAdapter(adapter);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = etLogin.getText().toString();
                String password = etPassword.getText().toString();
                String role = spinnerRole.getSelectedItem().toString();

                if (role.equals("Администратор")) role = "admin";
                else if (role.equals("Менеджер")) role = "manager";
                else role = "operator";

                if (login.isEmpty() || password.isEmpty()) {
                    Toast.makeText(UsersActivity.this, "Заполните все поля", Toast.LENGTH_SHORT).show();
                    return;
                }

                List<User> users = userManager.getUsers();
                for (User u : users) {
                    if (u.login.equals(login)) {
                        Toast.makeText(UsersActivity.this, "Пользователь уже существует", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                users.add(new User(login, password, role));
                userManager.saveUsers(users);
                Toast.makeText(UsersActivity.this, "Пользователь добавлен", Toast.LENGTH_SHORT).show();
                etLogin.setText("");
                etPassword.setText("");
            }
        });
    }
}