package com.example.tpkprogram.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tpkprogram.R;
import com.example.tpkprogram.models.User;
import com.example.tpkprogram.managers.UserManager;

import java.util.List;

public class UsersManagementActivity extends AppCompatActivity {

    EditText etSearch;
    Button btnSearch, btnAdd;
    ImageButton btnBack;
    Button btnFilterAll, btnFilterAdmin, btnFilterManager, btnFilterOperator;
    LinearLayout usersContainer;
    UserManager userManager;
    String currentFilter = "all";

    private static final int REQUEST_CODE_ADD_EDIT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_management);

        userManager = new UserManager(this);
        etSearch = findViewById(R.id.et_search);
        btnSearch = findViewById(R.id.btn_search);
        btnBack = findViewById(R.id.btn_back);
        btnAdd = findViewById(R.id.btn_add);
        btnFilterAll = findViewById(R.id.btn_filter_all);
        btnFilterAdmin = findViewById(R.id.btn_filter_admin);
        btnFilterManager = findViewById(R.id.btn_filter_manager);
        btnFilterOperator = findViewById(R.id.btn_filter_operator);
        usersContainer = findViewById(R.id.users_container);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UsersManagementActivity.this, EditUserActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchUser();
            }
        });

        btnFilterAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "all";
                loadUsers(currentFilter);
            }
        });

        btnFilterAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "admin";
                loadUsers(currentFilter);
            }
        });

        btnFilterManager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "manager";
                loadUsers(currentFilter);
            }
        });

        btnFilterOperator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentFilter = "operator";
                loadUsers(currentFilter);
            }
        });

        loadUsers(currentFilter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD_EDIT && resultCode == RESULT_OK) {
            loadUsers(currentFilter);
        }
    }

    private void loadUsers(String roleFilter) {
        usersContainer.removeAllViews();
        List<User> users = userManager.getUsers();
        boolean hasUsers = false;

        for (User user : users) {
            if (roleFilter.equals("all") || user.role.equals(roleFilter)) {
                hasUsers = true;
                addUserView(user);
            }
        }

        if (!hasUsers) {
            TextView empty = new TextView(this);
            empty.setText("Пользователи не найдены");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            usersContainer.addView(empty);
        }
    }

    private void addUserView(User user) {
        View view = getLayoutInflater().inflate(R.layout.item_user, usersContainer, false);
        TextView tvLogin = view.findViewById(R.id.tv_login);
        TextView tvRole = view.findViewById(R.id.tv_role);
        ImageButton btnEdit = view.findViewById(R.id.btn_edit);
        ImageButton btnDelete = view.findViewById(R.id.btn_delete);

        tvLogin.setText(user.login);
        tvRole.setText(getRoleName(user.role));

        final User finalUser = user;
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UsersManagementActivity.this, EditUserActivity.class);
                intent.putExtra("login", finalUser.login);
                intent.putExtra("password", finalUser.password);
                intent.putExtra("role", finalUser.role);
                startActivityForResult(intent, REQUEST_CODE_ADD_EDIT);
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteDialog(finalUser);
            }
        });

        usersContainer.addView(view);
    }

    private void showDeleteDialog(User user) {
        if (user.login.equals("admin")) {
            Toast.makeText(this, "Нельзя удалить администратора", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Удаление пользователя")
                .setMessage("Вы уверены, что хотите удалить пользователя " + user.login + "?")
                .setPositiveButton("ДА", (dialog, which) -> {
                    List<User> users = userManager.getUsers();
                    String loginToDelete = user.login;
                    for (int i = 0; i < users.size(); i++) {
                        if (users.get(i).login.equals(loginToDelete)) {
                            users.remove(i);
                            break;
                        }
                    }
                    userManager.saveUsers(users);
                    loadUsers(currentFilter);
                    Toast.makeText(UsersManagementActivity.this, "Пользователь удален", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("НЕТ", null)
                .show();
    }

    private void searchUser() {
        String searchLogin = etSearch.getText().toString().trim();
        if (searchLogin.isEmpty()) {
            loadUsers(currentFilter);
            return;
        }

        usersContainer.removeAllViews();
        List<User> users = userManager.getUsers();
        boolean found = false;

        for (User user : users) {
            if (user.login.toLowerCase().contains(searchLogin.toLowerCase())) {
                found = true;
                addUserView(user);
            }
        }

        if (!found) {
            TextView empty = new TextView(this);
            empty.setText("Пользователь не найден");
            empty.setTextSize(18);
            empty.setTextColor(0xFF546E7A);
            empty.setPadding(16, 32, 16, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            usersContainer.addView(empty);
        }
    }

    private String getRoleName(String role) {
        switch (role) {
            case "admin": return "Администратор";
            case "manager": return "Менеджер";
            case "operator": return "Оператор";
            default: return "Неизвестно";
        }
    }
}