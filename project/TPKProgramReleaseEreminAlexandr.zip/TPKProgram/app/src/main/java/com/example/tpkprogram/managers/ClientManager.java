package com.example.tpkprogram.managers;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.tpkprogram.models.Client;

import java.util.ArrayList;
import java.util.List;

public class ClientManager {
    private static final String PREF_NAME = "app_data";
    private static final String KEY_CLIENTS = "clients";
    private SharedPreferences prefs;

    public ClientManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        initDefaultClients();
    }

    private void initDefaultClients() {
        if (!prefs.contains(KEY_CLIENTS)) {
            String defaultClients = "Издательство 'Наука':1:Петров И.С.:+7 (912) 345-67-89:sasha@yandex.ru:г. Тверь, ул.;Рекламное агентство 'Промо':2:Сидорова А.В.:+7 (923) 456-78-90:cawn@yandex.ru:г. Тверь, пр. Калинина, д.15";
            prefs.edit().putString(KEY_CLIENTS, defaultClients).apply();
        }
    }

    public List<Client> getClients() {
        List<Client> clients = new ArrayList<>();
        String data = prefs.getString(KEY_CLIENTS, "");
        if (!data.isEmpty()) {
            String[] clientStrings = data.split(";");
            for (String clientStr : clientStrings) {
                String[] parts = clientStr.split(":");
                if (parts.length == 6) {
                    try {
                        int id = Integer.parseInt(parts[1]);
                        clients.add(new Client(id, parts[0], parts[2], parts[3], parts[4], parts[5]));
                    } catch (NumberFormatException e) {
                    }
                }
            }
        }
        return clients;
    }

    public int getNextId() {
        List<Client> clients = getClients();
        int maxId = 0;
        for (Client client : clients) {

            if (client.id > maxId) maxId = client.id;
        }
        return maxId + 1;
    }

    public void saveClients(List<Client> clients) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < clients.size(); i++) {
            Client c = clients.get(i);
            sb.append(c.name).append(":").append(c.id).append(":").append(c.contactPerson).append(":").append(c.phone).append(":").append(c.email).append(":").append(c.address);
            if (i < clients.size() - 1) sb.append(";");
        }
        prefs.edit().putString(KEY_CLIENTS, sb.toString()).apply();
    }
}