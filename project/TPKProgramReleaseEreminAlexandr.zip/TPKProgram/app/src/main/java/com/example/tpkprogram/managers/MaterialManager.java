package com.example.tpkprogram.managers;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.tpkprogram.models.Material;

import java.util.ArrayList;
import java.util.List;

public class MaterialManager {
    private static final String PREF_NAME = "app_data";
    private static final String KEY_MATERIALS = "materials";
    private SharedPreferences prefs;

    public MaterialManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        initDefaultMaterials();
    }

    private void initDefaultMaterials() {
        if (!prefs.contains(KEY_MATERIALS)) {
            String defaultMaterials = "Бумага А4:5000:лист:5.50;Краска черная:1000:мл:120.00;Клей ПВА:200:г:85.00";
            prefs.edit().putString(KEY_MATERIALS, defaultMaterials).apply();
        }
    }

    public List<Material> getMaterials() {
        List<Material> materials = new ArrayList<>();
        String data = prefs.getString(KEY_MATERIALS, "");
        if (!data.isEmpty()) {
            String[] materialStrings = data.split(";");
            for (String matStr : materialStrings) {
                String[] parts = matStr.split(":");
                if (parts.length == 4) {
                    materials.add(new Material(parts[0], Integer.parseInt(parts[1]), parts[2], Double.parseDouble(parts[3])));
                }
            }
        }
        return materials;
    }

    public void saveMaterials(List<Material> materials) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < materials.size(); i++) {
            Material m = materials.get(i);
            sb.append(m.name).append(":").append(m.stock).append(":").append(m.unit).append(":").append(m.price);
            if (i < materials.size() - 1) sb.append(";");
        }
        prefs.edit().putString(KEY_MATERIALS, sb.toString()).apply();
    }
}