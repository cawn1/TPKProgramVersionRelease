package com.example.tpkprogram.managers;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.tpkprogram.models.Order;
import com.example.tpkprogram.models.OrderMaterial;

import java.util.ArrayList;
import java.util.List;

public class OrderManager {
    private static final String PREF_NAME = "app_data";
    private static final String KEY_ORDERS = "orders";
    private SharedPreferences prefs;

    public OrderManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public List<Order> getOrders() {
        List<Order> orders = new ArrayList<>();
        String data = prefs.getString(KEY_ORDERS, "");
        if (data.isEmpty()) {
            return orders;
        }

        String[] orderStrings = data.split("###ORDER###");
        for (String orderStr : orderStrings) {
            if (orderStr.isEmpty()) continue;

            try {
                String[] parts = orderStr.split("###FIELD###", -1);
                if (parts.length < 11) continue;

                int id = Integer.parseInt(parts[0]);
                String clientName = parts[1];
                String productType = parts[2];
                int quantity = Integer.parseInt(parts[3]);
                String deadline = parts[4];
                String description = parts[5];
                String operatorLogin = parts[6];
                String status = parts[7];
                double materialsCost = Double.parseDouble(parts[8]);
                double laborCost = Double.parseDouble(parts[9]);
                double discountPercent = Double.parseDouble(parts[10]);

                Order order = new Order(id, clientName, productType, quantity, deadline,
                        description, operatorLogin, status,
                        materialsCost, laborCost, discountPercent);

                if (parts.length > 11 && !parts[11].isEmpty()) {
                    String[] materialStrings = parts[11].split("###MATERIAL###");
                    for (String matStr : materialStrings) {
                        if (matStr.isEmpty()) continue;
                        String[] matParts = matStr.split("###MATFIELD###", -1);
                        if (matParts.length == 4) {
                            order.materials.add(new OrderMaterial(matParts[0],
                                    Integer.parseInt(matParts[1]), matParts[2],
                                    Double.parseDouble(matParts[3])));
                        }
                    }
                }
                orders.add(order);
            } catch (Exception e) {
                continue;
            }
        }
        return orders;
    }

    public int getNextId() {
        List<Order> orders = getOrders();
        int maxId = 0;
        for (Order order : orders) {
            if (order.id > maxId) maxId = order.id;
        }
        return maxId + 1;
    }

    public void saveOrders(List<Order> orders) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < orders.size(); i++) {
            Order o = orders.get(i);
            sb.append(o.id).append("###FIELD###").append(o.clientName).append("###FIELD###").append(o.productType)
                    .append("###FIELD###").append(o.quantity).append("###FIELD###").append(o.deadline).append("###FIELD###")
                    .append(o.description).append("###FIELD###").append(o.operatorLogin).append("###FIELD###")
                    .append(o.status).append("###FIELD###").append(o.materialsCost).append("###FIELD###")
                    .append(o.laborCost).append("###FIELD###").append(o.discountPercent).append("###FIELD###");

            for (int j = 0; j < o.materials.size(); j++) {
                OrderMaterial m = o.materials.get(j);
                sb.append(m.name).append("###MATFIELD###").append(m.quantity).append("###MATFIELD###")
                        .append(m.unit).append("###MATFIELD###").append(m.price);
                if (j < o.materials.size() - 1) sb.append("###MATERIAL###");
            }

            if (i < orders.size() - 1) sb.append("###ORDER###");
        }
        prefs.edit().putString(KEY_ORDERS, sb.toString()).commit();
    }
}