package com.example.tpkprogram.managers;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.tpkprogram.models.ProductType;

import java.util.ArrayList;
import java.util.List;

public class ProductTypeManager {
    private static final String PREF_NAME = "app_data";
    private static final String KEY_PRODUCT_TYPES = "product_types";
    private SharedPreferences prefs;

    public ProductTypeManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        initDefaultProductTypes();
    }

    private void initDefaultProductTypes() {
        if (!prefs.contains(KEY_PRODUCT_TYPES)) {
            String defaultTypes = "Книги в твердом переплете:1:Изготовление книг с твердым переплетом;Книги в мягкой обложке:2:Изготовление книг с мягкой обложкой;Журналы:3:Печать журналов различного формата";
            prefs.edit().putString(KEY_PRODUCT_TYPES, defaultTypes).apply();
        }
    }

    public List<ProductType> getProductTypes() {
        List<ProductType> types = new ArrayList<>();
        String data = prefs.getString(KEY_PRODUCT_TYPES, "");
        if (!data.isEmpty()) {
            String[] typeStrings = data.split(";");
            for (String typeStr : typeStrings) {
                String[] parts = typeStr.split(":");
                if (parts.length == 3) {
                    try {
                        int id = Integer.parseInt(parts[1]);
                        types.add(new ProductType(id, parts[0], parts[2]));
                    } catch (NumberFormatException e) {
                    }
                }
            }
        }
        return types;
    }

    public int getNextId() {
        List<ProductType> types = getProductTypes();
        int maxId = 0;
        for (ProductType type : types) {
            if (type.id > maxId) maxId = type.id;
        }
        return maxId + 1;
    }

    public void saveProductTypes(List<ProductType> types) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < types.size(); i++) {
            ProductType t = types.get(i);
            sb.append(t.name).append(":").append(t.id).append(":").append(t.description);
            if (i < types.size() - 1) sb.append(";");
        }
        prefs.edit().putString(KEY_PRODUCT_TYPES, sb.toString()).apply();
    }
}