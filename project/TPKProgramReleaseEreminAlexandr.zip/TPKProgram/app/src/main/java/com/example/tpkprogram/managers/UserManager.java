package com.example.tpkprogram.managers;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.tpkprogram.models.User;

import java.util.ArrayList;
import java.util.List;

public class UserManager {
    private static final String PREF_NAME = "app_data";
    private static final String KEY_USERS = "users";
    private SharedPreferences prefs;

    public UserManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        initDefaultUsers();
    }

    private void initDefaultUsers() {
        List<User> users = getUsers();
        boolean hasAdmin = false;
        boolean hasManager = false;
        boolean hasOperator = false;

        for (User user : users) {
            if (user.login.equals("admin")) hasAdmin = true;
            if (user.login.equals("manager")) hasManager = true;
            if (user.login.equals("operator")) hasOperator = true;
        }

        if (!hasAdmin) {
            users.add(new User("admin", "password", "admin"));
        }

        if (!hasManager) {
            users.add(new User("manager", "password", "manager"));
        }

        if (!hasOperator) {
            users.add(new User("operator", "password", "operator"));
        }

        if (!hasAdmin || !hasManager || !hasOperator) {
            saveUsers(users);
        }
    }

    public List<User> getUsers() {
        List<User> users = new ArrayList<>();
        String data = prefs.getString(KEY_USERS, "");
        if (!data.isEmpty()) {
            String[] userStrings = data.split(";");
            for (String userStr : userStrings) {
                String[] parts = userStr.split(":");
                if (parts.length == 3) {
                    users.add(new User(parts[0], parts[1], parts[2]));
                }
            }
        }
        return users;
    }

    public void saveUsers(List<User> users) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < users.size(); i++) {
            User u = users.get(i);
            sb.append(u.login).append(":").append(u.password).append(":").append(u.role);
            if (i < users.size() - 1) sb.append(";");
        }
        prefs.edit().putString(KEY_USERS, sb.toString()).apply();
    }

    public User authenticate(String login, String password) {
        for (User user : getUsers()) {
            if (user.login.equals(login) && user.password.equals(password)) {
                return user;
            }
        }
        return null;
    }
}