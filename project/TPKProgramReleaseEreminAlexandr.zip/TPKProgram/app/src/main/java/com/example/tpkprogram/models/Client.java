package com.example.tpkprogram.models;

public class Client {
    public int id;
    public String name;
    public String contactPerson;
    public String phone;
    public String email;
    public String address;

    public Client(int id, String name, String contactPerson, String phone, String email, String address) {
        this.id = id;
        this.name = name;
        this.contactPerson = contactPerson;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }
}