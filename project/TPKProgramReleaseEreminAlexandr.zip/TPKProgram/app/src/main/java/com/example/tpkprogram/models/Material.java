package com.example.tpkprogram.models;

public class Material {
    public String name;
    public int stock;
    public String unit;
    public double price;

    public Material(String name, int stock, String unit, double price) {
        this.name = name;
        this.stock = stock;
        this.unit = unit;
        this.price = price;
    }
}