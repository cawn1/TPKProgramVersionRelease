package com.example.tpkprogram.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Order implements Serializable {
    public int id;
    public String clientName;
    public String productType;
    public int quantity;
    public String deadline;
    public String description;
    public String operatorLogin;
    public String status;
    public double materialsCost;
    public double laborCost;
    public double discountPercent;
    public List<OrderMaterial> materials;

    public Order(int id, String clientName, String productType, int quantity, String deadline,
                 String description, String operatorLogin, String status,
                 double materialsCost, double laborCost, double discountPercent) {
        this.id = id;
        this.clientName = clientName;
        this.productType = productType;
        this.quantity = quantity;
        this.deadline = deadline;
        this.description = description;
        this.operatorLogin = operatorLogin;
        this.status = status;
        this.materialsCost = materialsCost;
        this.laborCost = laborCost;
        this.discountPercent = discountPercent;
        this.materials = new ArrayList<>();
    }
}