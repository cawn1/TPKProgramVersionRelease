package com.example.tpkprogram.models;

import java.io.Serializable;

public class OrderMaterial implements Serializable {
    public String name;
    public int quantity;
    public String unit;
    public double price;

    public OrderMaterial(String name, int quantity, String unit, double price) {
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
        this.price = price;
    }
}