package com.example.tpkprogram.models;

public class User {
    public String login;
    public String password;
    public String role;

    public User(String login, String password, String role) {
        this.login = login;
        this.password = password;
        this.role = role;
    }
}